# PyroCMS Streams API Sample Module

This module illustrates the use of the Streams Core API to handle data interaction within a PyroStreams module. It creates a simple FAQ stream with a question field and an answer field.

## Installation

Unzip the folde, rename it to 'faq', and drop it into your addons/_site\_ref_/modules or addons/shared\_addons/modules folder. Install from the admin panel.