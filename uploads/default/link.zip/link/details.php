<?php defined('BASEPATH') or exit('No direct script access allowed');

class Module_Link extends Module
{
    public $version = '1.0';

    public function info()
    {
        return array(
            'name' => array(
                'en' => 'Link'
            ),
            'description' => array(
                'en' => 'Link module'
            ),
            'frontend' => true,
            'backend' => true,
            'menu' => 'content',
            'sections' => array(
                'link' => array(
                    'name' => 'link:links',
                    'uri' => 'admin/link',
                    'shortcuts' => array(
                        'create' => array(
                            'name' => 'link:new',
                            'uri' => 'admin/link/create',
                            'class' => 'add'
                        )
                    )
                )
            )
        );
    }

    /**
     * Install
     *
     * This function will set up our
     * FAQ/Category streams.
     */
    public function install()
    {
        // We're using the streams API to
        // do data setup.
        $this->load->driver('Streams');

        $this->load->language('link/link');
        $namespace="link";
        $streamname="links";

        // Add faqs streams
        if ( ! $this->streams->streams->add_stream('lang:link:links', $streamname, $namespace, $namespace.'-', null)) return false;
        

        //$faq_categories

        // Add some fields
        $fields = array(
            array(
                'name' => 'Nama',
                'slug' => 'nama',
                'namespace' => $namespace,
                'type' => 'text',
                'extra' => array('max_length' => 200),
                'assign' => $streamname,
                'title_column' => true,
                'required' => true
                
            ),
            array(
                'name' => 'Url',
                'slug' => 'url',
                'namespace' => $namespace,
                'type' => 'url',
                'assign' => $streamname,
                'required' => true
            ),
            array(
                'name' => 'Tipe',
                'slug' => 'tipe',
                'namespace' => $namespace,
                'type' => 'choice',
                'assign' => $streamname,
                'extra' => array(
                    'choice_type'=> 'radio',
                    'choice_data'=> "organisasi_dunia : Organisasi Dunia\n kementrian : Kementrian\n upt : UPT"
                )
                
                
            )
        );

        $this->streams->fields->add_fields($fields);

        $this->streams->streams->update_stream($streamname, $namespace, array(
            'view_options' => array(
                'id',
                'nama',
                'url',
                'tipe'                
            )
        ));

        

        return true;
    }

    /**
     * Uninstall
     *
     * Uninstall our module - this should tear down
     * all information associated with it.
     */
    public function uninstall()
    {
        $this->load->driver('Streams');

        // For this teardown we are using the simple remove_namespace
        // utility in the Streams API Utilties driver.
        $this->streams->utilities->remove_namespace('link');

        return true;
    }

    public function upgrade($old_version)
    {
        return true;
    }

    public function help()
    {
        // Return a string containing help info
        // You could include a file and return it here.
        return "No documentation has been added for this module.<br />Contact the module developer for assistance.";
    }

}