    <div class="col-lg-12">         
    <div class="row">
            <div class="col-lg-2">
                <div class="footer-menu">
                    <h5>Organisasi Dunia</h5>
                    <ul style="list-unstyled">
                       {{ links.entries }}
                        <li class="answer">
                            <h4 id="{{ id }}">{{ nama }}</h4>
                            <p>{{ url }}</p>
                        </li>
                        {{ /links.entries }}
                    </ul>
                </div>


            </div>
            <div class="col-lg-2">
                <div class="footer-menu">
                    <h5>Kementrian</h5>

                    <ul style="list-unstyled">
                        <li><a href="#"> Kemenkes</a></li>
                        <li><a href="#"> Ditjen Bina Gizi dan KIA</a></li>
                        <li><a href="#"> Ditjen Bina Upaya Kesehatan</a></li>
                        <li><a href="#"> Ditjen Binfar dan Alkes</a></li>
                        <li><a href="#"> Badan Litbangkes</a></li>
                        <li><a href="#"> Badan PPSDMKes</a></li>

                    </ul>
                </div>
            </div>
            <div class="col-lg-2">
                <div class="footer-menu">
                    <h5>UPT</h5>
                    <ul>
                        <li>KKP Jayapura</li>
                        <li>KKP Pontianak</li>
                        <li>KKP Palembang</li>
                        <li>KKP Kelas 1 Soekarno-Hatta</li>
                        <li>KKP Samarinda</li>
                        <li>KKP Panjang</li>
                        <li>BBTKLPP Surabaya</li>
                        <li>BBTKLPP Jakarta</li>
                        <li>KKP Semarang</li>
                        <li>KKP Balikpapan</li>
                        <li>BBTKLPP Banjarbaru</li>
                        <li>KKP tanjung Priok</li>
                        <li>KKP Medan</li>
                        <li>BBTKLPP Yogyakarta</li>
                    </ul>

                </div>
            </div>
    </div>
    </div>