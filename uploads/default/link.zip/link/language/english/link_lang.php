<?php

$lang['link:new']                        = 'New link';
$lang['link:edit']                       = 'Edit link';
$lang['link:link']                        = 'link';
$lang['link:links']                       = 'links';
$lang['link:no_links']                    = 'There are currently no links';
$lang['link:question']                   = 'Question';
$lang['link:questions']                  = 'Questions';
$lang['link:answer']                     = 'Answer';
$lang['link:answers']                    = 'Answers';

$lang['link:submit_success']             = 'New link submitted successfully.';
$lang['link:submit_failure']             = 'There was a problem submitting your link.';
$lang['link:deleted']                    = 'The link was deleted.';

$lang['link:categories']                 = 'Categories';
$lang['link:category:new']				= 'New Category';

$lang['link:streams']                    = 'Streams';
$lang['link:view_options']               = 'View Options';
$lang['link:field_assignments']          = 'Field Assignments';
$lang['link:new_assignment']          	= 'New Field Assignment';
$lang['link:edit_assignment']          	= 'Edit Field Assignment';