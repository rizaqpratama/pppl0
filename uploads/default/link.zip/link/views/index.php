<div class="content">

<h2>{{ template:title }}</h2>

{{ if links_exist==true }}
<div id="faq">
    <h3>{{ helper:lang line="link:questions" }}</h3>
    {{ pagination:links }}
   
    <div id="answers">
        <h3>{{ helper:lang line="link:answers" }}</h3>
        <ol> 
            {{ links.entries }}
            <li class="answer">
                <h4 id="{{ id }}">{{ nama }}</h4>
                <p>{{ url }}</p>
            </li>
            {{ /links.entries }}
        </ol>
    </div>
</div>
{{ else }}
<h4>{{ helper:lang line="link:no_kegiatans" }}</h4>
{{ endif }}

</div>