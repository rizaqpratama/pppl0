<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Link extends Public_Controller
{

    /**
     * The constructor
     * @access public
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->lang->load('link');
        $this->load->driver('Streams');
        $this->template->append_css('module::faq.css');
    }
     /**
     * List all FAQs
     *
     * We are using the Streams API to grab
     * data from the faqs database. It handles
     * pagination as well.
     *
     * @access	public
     * @return	void
     */
    public function index()
    {
        $params = array(
            'stream' => 'links',
            'namespace' => 'link',
            'paginate' => 'yes',
            'pag_segment' => 4
        );

        $links = $this->streams->entries->get_entries($params);
        $links_exist= count($links);

        // Build the page
        $this->template->title($this->module_details['name'])
                ->set('links',$links)
                ->set('links_exist',$links_exist)
                ->build('index');
    }

}

/* End of file faq.php */
