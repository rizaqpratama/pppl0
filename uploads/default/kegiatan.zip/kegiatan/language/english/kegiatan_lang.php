<?php

$lang['kegiatan:new']                        = 'New kegiatan';
$lang['kegiatan:edit']                       = 'Edit kegiatan';
$lang['kegiatan:kegiatan']                        = 'kegiatan';
$lang['kegiatan:kegiatans']                       = 'kegiatans';
$lang['kegiatan:no_kegiatans']                    = 'There are currently no kegiatans';
$lang['kegiatan:question']                   = 'Question';
$lang['kegiatan:questions']                  = 'Questions';
$lang['kegiatan:answer']                     = 'Answer';
$lang['kegiatan:answers']                    = 'Answers';

$lang['kegiatan:submit_success']             = 'New kegiatan submitted successfully.';
$lang['kegiatan:submit_failure']             = 'There was a problem submitting your kegiatan.';
$lang['kegiatan:deleted']                    = 'The kegiatan was deleted.';

$lang['kegiatan:categories']                 = 'Categories';
$lang['kegiatan:category:new']				= 'New Category';

$lang['kegiatan:streams']                    = 'Streams';
$lang['kegiatan:view_options']               = 'View Options';
$lang['kegiatan:field_assignments']          = 'Field Assignments';
$lang['kegiatan:new_assignment']          	= 'New Field Assignment';
$lang['kegiatan:edit_assignment']          	= 'Edit Field Assignment';