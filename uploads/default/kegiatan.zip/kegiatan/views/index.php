<div class="content">

<h2>{{ template:title }}</h2>

{{ if kegiatans_exist==true }}
<div id="faq">
    <h3>{{ helper:lang line="kegiatan:questions" }}</h3>
    {{ pagination:links }}
   
    <div id="answers">
        <h3>{{ helper:lang line="kegiatan:answers" }}</h3>
        <ol> 
            {{ kegiatans.entries }}
            <li class="answer">
                <h4 id="{{ id }}">{{ nama }}</h4>
                <p>{{ deskripsi }}</p>
            </li>
            {{ /kegiatans.entries }}
        </ol>
    </div>
</div>
{{ else }}
<h4>{{ helper:lang line="kegiatan:no_kegiatans" }}</h4>
{{ endif }}

</div>