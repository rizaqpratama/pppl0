<?php defined('BASEPATH') or exit('No direct script access allowed');

class Module_Kegiatan extends Module
{
    public $version = '1.0';

    public function info()
    {
        return array(
            'name' => array(
                'en' => 'Kegiatan'
            ),
            'description' => array(
                'en' => 'Kegiatan Ditjen PPPL'
            ),
            'frontend' => true,
            'backend' => true,
            'menu' => 'content',
            'sections' => array(
                'kegiatan' => array(
                    'name' => 'kegiatan:kegiatans',
                    'uri' => 'admin/kegiatan',
                    'shortcuts' => array(
                        'create' => array(
                            'name' => 'kegiatan:new',
                            'uri' => 'admin/kegiatan/create',
                            'class' => 'add'
                        )
                    )
                )
            )
        );
    }

    /**
     * Install
     *
     * This function will set up our
     * FAQ/Category streams.
     */
    public function install()
    {
        // We're using the streams API to
        // do data setup.
        $this->load->driver('Streams');

        $this->load->language('kegiatan/kegiatan');
        $namespace="kegiatan";

        // Add faqs streams
        if ( ! $this->streams->streams->add_stream('lang:kegiatan:kegiatans', 'kegiatans', $namespace, $namespace.'-', null)) return false;
        

        //$faq_categories

        // Add some fields
        $fields = array(
            array(
                'name' => 'Nama',
                'slug' => 'nama',
                'namespace' => $namespace,
                'type' => 'text',
                'extra' => array('max_length' => 200),
                'assign' => 'kegiatans',
                'title_column' => true,
                'required' => true
                
            ),
            array(
                'name' => 'Deskripsi',
                'slug' => 'deskripsi',
                'namespace' => $namespace,
                'type' => 'wysiwyg',
                'assign' => 'kegiatans',
                'required' => true
            ),
            array(
                'name' => 'Waktu',
                'slug' => 'waktu',
                'namespace' => $namespace,
                'type' => 'datetime',
                'assign' => 'kegiatans'
                
            ),
            array(
                'name' => 'Lokasi',
                'slug' => 'lokasi',
                'namespace' => $namespace,
                'type' => 'text',
                'assign' => 'kegiatans'
               
            )
        );

        $this->streams->fields->add_fields($fields);

        $this->streams->streams->update_stream('kegiatans', $namespace, array(
            'view_options' => array(
                'id',
                'nama',
                'deskripsi',
                'waktu',
                'lokasi'
            )
        ));

        

        return true;
    }

    /**
     * Uninstall
     *
     * Uninstall our module - this should tear down
     * all information associated with it.
     */
    public function uninstall()
    {
        $this->load->driver('Streams');

        // For this teardown we are using the simple remove_namespace
        // utility in the Streams API Utilties driver.
        $this->streams->utilities->remove_namespace($namespace);

        return true;
    }

    public function upgrade($old_version)
    {
        return true;
    }

    public function help()
    {
        // Return a string containing help info
        // You could include a file and return it here.
        return "No documentation has been added for this module.<br />Contact the module developer for assistance.";
    }

}