<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$route['kegiatan/admin/categories(:any)'] = 'admin_categories$1';
$route['kegiatan/admin/streams(:any)'] = 'admin_streams$1';