<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Kegiatan extends Public_Controller
{

    /**
     * The constructor
     * @access public
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->lang->load('kegiatan');
        $this->load->driver('Streams');
        $this->template->append_css('module::faq.css');
    }
     /**
     * List all FAQs
     *
     * We are using the Streams API to grab
     * data from the faqs database. It handles
     * pagination as well.
     *
     * @access	public
     * @return	void
     */
    public function index()
    {
        $params = array(
            'stream' => 'kegiatans',
            'namespace' => 'kegiatan',
            'paginate' => 'yes',
            'pag_segment' => 4
        );

        $kegiatans = $this->streams->entries->get_entries($params);
        $kegiatans_exist= count($kegiatans);

        // Build the page
        $this->template->title($this->module_details['name'])
                ->set('kegiatans',$kegiatans)
                ->set('kegiatans_exist',$kegiatans_exist)
                ->build('index');
    }

}

/* End of file faq.php */
