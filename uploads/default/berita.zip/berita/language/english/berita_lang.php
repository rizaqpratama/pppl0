<?php

$lang['berita:new']                        = 'New berita';
$lang['berita:edit']                       = 'Edit berita';
$lang['berita:berita']                     = 'berita';
$lang['berita:beritas']                    = 'beritas';
$lang['berita:no_beritas']                 = 'There are currently no beritas';
$lang['berita:question']                   = 'Question';
$lang['berita:questions']                  = 'Questions';
$lang['berita:answer']                     = 'Answer';
$lang['berita:answers']                    = 'Answers';

$lang['berita:submit_success']             = 'New berita submitted successfully.';
$lang['berita:submit_failure']             = 'There was a problem submitting your berita.';
$lang['berita:deleted']                    = 'The berita was deleted.';

$lang['berita:categories']                 = 'Categories';
$lang['berita:category:new']				= 'New Category';

$lang['berita:streams']                    = 'Streams';
$lang['berita:view_options']               = 'View Options';
$lang['berita:field_assignments']          = 'Field Assignments';
$lang['berita:new_assignment']          	= 'New Field Assignment';
$lang['berita:edit_assignment']          	= 'Edit Field Assignment';