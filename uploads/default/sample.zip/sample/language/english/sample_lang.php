<?php
//messages
$lang['sample:success']			=	'It worked';
$lang['sample:error']			=	'It didn\'t work';
$lang['sample:no_items']		=	'No Items';

//page titles
$lang['sample:create']			=	'Create Item';

//labels
$lang['sample:name']			=	'Name';
$lang['sample:slug']			=	'Slug';
$lang['sample:manage']			=	'Manage';
$lang['sample:item_list']		=	'Item List';
$lang['sample:view']			=	'View';
$lang['sample:edit']			=	'Edit';
$lang['sample:delete']			=	'Delete';

//buttons
$lang['sample:custom_button']	=	'Custom Button';
$lang['sample:items']			=	'Items';
?>